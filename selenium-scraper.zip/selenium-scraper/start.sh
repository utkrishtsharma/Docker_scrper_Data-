#!/bin/bash

# Start Xvfb (virtual display)
Xvfb :99 -screen 0 1024x768x24 &

# Start Fluxbox window manager
DISPLAY=:99 fluxbox &

# Start x11vnc server
x11vnc -display :99 -nopw -listen 0.0.0.0 -xkb -forever -shared &

# Start noVNC web client
novnc --listen 6080 --vnc localhost:5900 &

# Start Flask application
DISPLAY=:99 python app.py