from flask import Flask, render_template, request, jsonify
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import time
import json
import os

app = Flask(__name__)

def setup_driver():
    """Setup Chrome driver with optimal settings for scraping"""
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    
    # Set display for VNC
    os.environ['DISPLAY'] = ':99'
    
    driver = webdriver.Chrome(options=chrome_options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
    return driver

def scrape_google_results(query, num_results=10):
    """Scrape Google search results"""
    driver = setup_driver()
    results = []
    
    try:
        # Navigate to Google
        driver.get('https://www.google.com')
        
        # Find search box and enter query
        search_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.NAME, 'q'))
        )
        search_box.clear()
        search_box.send_keys(query)
        search_box.send_keys(Keys.RETURN)
        
        # Wait for results to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'div.g'))
        )
        
        # Extract search results
        search_results = driver.find_elements(By.CSS_SELECTOR, 'div.g')
        
        for i, result in enumerate(search_results[:num_results]):
            try:
                # Extract title
                title_element = result.find_element(By.CSS_SELECTOR, 'h3')
                title = title_element.text if title_element else 'No title'
                
                # Extract URL
                link_element = result.find_element(By.CSS_SELECTOR, 'a')
                url = link_element.get_attribute('href') if link_element else 'No URL'
                
                # Extract snippet
                snippet_element = result.find_elements(By.CSS_SELECTOR, 'span')
                snippet = ''
                for span in snippet_element:
                    if len(span.text) > 50:  # Get the longest text span as snippet
                        snippet = span.text
                        break
                
                results.append({
                    'rank': i + 1,
                    'title': title,
                    'url': url,
                    'snippet': snippet[:200] + '...' if len(snippet) > 200 else snippet
                })
                
            except Exception as e:
                print(f"Error extracting result {i+1}: {e}")
                continue
        
        return {'success': True, 'results': results, 'query': query}
        
    except Exception as e:
        return {'success': False, 'error': str(e)}
    
    finally:
        driver.quit()

@app.route('/')
def index():
    """Serve the main interface"""
    return render_template('index.html')

@app.route('/scrape', methods=['POST'])
def scrape():
    """Handle scraping request"""
    data = request.get_json()
    query = data.get('query', '')
    num_results = int(data.get('num_results', 10))
    
    if not query:
        return jsonify({'success': False, 'error': 'Query is required'})
    
    if num_results > 20:
        num_results = 20  # Limit to prevent overload
    
    result = scrape_google_results(query, num_results)
    return jsonify(result)

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'vnc_url': 'http://localhost:6080'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)