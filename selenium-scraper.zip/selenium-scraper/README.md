# 🔍 Selenium Google Search Scraper with Web Desktop

A lightweight, fast-spinning Docker container with Selenium for Google search scraping, featuring a web-accessible desktop environment and beautiful UI.

## ✨ Features

- **Ultra-fast startup** with Alpine Linux base
- **Web-accessible desktop** via noVNC on port 6080
- **Headless Chrome** with anti-detection measures
- **Beautiful, responsive UI** for search input
- **Real-time scraping** of Google search results
- **Docker Compose** ready for easy deployment

## 🚀 Quick Start

### Prerequisites
- Docker and Docker Compose installed
- Ports 5000 and 6080 available

### 1. Clone and Setup
```bash
# Create project directory
mkdir selenium-scraper && cd selenium-scraper

# Create templates directory
mkdir templates

# Copy all the provided files to appropriate locations:
# - Dockerfile
# - docker-compose.yml
# - requirements.txt
# - supervisord.conf
# - app.py
# - start.sh
# - templates/index.html
```

### 2. Build and Run
```bash
# Build and start the container
docker-compose up --build

# Or run in background
docker-compose up -d --build
```

### 3. Access the Application
- **Web UI**: http://localhost:5000
- **Desktop (VNC)**: http://localhost:6080
- **Health Check**: http://localhost:5000/health

## 🖥️ Usage

### Web Interface
1. Open http://localhost:5000 in your browser
2. Enter your search query
3. Select number of results (1-20)
4. Click "Search" to start scraping
5. View results in real-time

### Desktop Access
- Access the virtual desktop at http://localhost:6080
- Watch the scraping process in real-time
- Debug and inspect browser behavior

## 📁 Project Structure

```
selenium-scraper/
├── Dockerfile              # Alpine-based container
├── docker-compose.yml      # Multi-service orchestration
├── requirements.txt        # Python dependencies
├── supervisord.conf        # Process management
├── app.py                 # Flask application
├── start.sh               # Startup script
├── templates/
│   └── index.html         # Beautiful web interface
└── data/                  # Volume for data persistence
```

## 🛠️ Configuration

### Environment Variables
- `DISPLAY`: Set to `:99` for virtual display
- `PYTHONUNBUFFERED`: Enables real-time logging

### Chrome Options
The scraper uses optimized Chrome options:
- Headless mode for performance
- Anti-detection measures
- Custom user agent
- Optimized window size

### Ports
- `5000`: Flask web application
- `6080`: noVNC web interface
- `5900`: VNC server (internal)

## 🔧 Customization

### Modify Search Parameters
Edit `app.py` to change:
- Maximum results limit
- Search timeouts
- Chrome driver options
- Result extraction logic

### UI Customization
Edit `templates/index.html` to modify:
- Styling and colors
- Form fields
- Result display format

### Docker Optimization
Modify `Dockerfile` for:
- Different base images
- Additional tools
- Custom configurations

## 📊 API Endpoints

### POST /scrape
Scrape Google search results
```json
{
    "query": "your search query",
    "num_results": 10
}
```

### GET /health
Health check endpoint
```json
{
    "status": "healthy",
    "vnc_url": "http://localhost:6080"
}
```

## 🚦 Monitoring

### Container Logs
```bash
# View all logs
docker-compose logs -f

# View specific service
docker-compose logs -f selenium-scraper
```

### Process Status
```bash
# Check running processes
docker-compose exec selenium-scraper ps aux
```

## 🔍 Troubleshooting

### Common Issues

1. **Container won't start**
   - Check port availability
   - Verify Docker daemon is running

2. **VNC not accessible**
   - Ensure port 6080 is not blocked
   - Check container logs for errors

3. **Scraping fails**
   - Verify internet connectivity
   - Check Chrome driver compatibility

### Debug Commands
```bash
# Enter container shell
docker-compose exec selenium-scraper sh

# Check display
docker-compose exec selenium-scraper echo $DISPLAY

# Test Chrome
docker-compose exec selenium-scraper chromium-browser --version
```

## ⚡ Performance Tips

1. **Resource Limits**: Add memory/CPU limits in docker-compose.yml
2. **Caching**: Implement result caching for repeated queries
3. **Scaling**: Use multiple containers for high load
4. **Optimization**: Tune Chrome options for your use case

## 🛡️ Security Notes

- The container runs as root for simplicity
- VNC has no password (suitable for development only)
- For production, add authentication and SSL
- Consider network isolation and firewall rules

## 📄 License

This project is open-source and available under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

---

**Happy Scraping! 🎉**